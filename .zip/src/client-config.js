const clientConfig = {
	siteUrl: 'https://sabhitech.com',
};

export default clientConfig;
