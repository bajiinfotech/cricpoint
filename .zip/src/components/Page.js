import React from 'react';
import Navbar from "./Navbar";

const Page = ( props ) => {

	const { id } = props;

	return (
		<React.Fragment>
			
		</React.Fragment>
	)
};

export default Page;
