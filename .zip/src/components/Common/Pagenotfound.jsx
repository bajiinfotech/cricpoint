import React from 'react'

const Pagenotfound = () => {
  return (
    <div>
      <div className='container'>
        <h3 className='text-center'>Page Not Found</h3>
      </div>
    </div>
  )
}

export default Pagenotfound