import React from 'react'
import axios from 'axios'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Helmet } from 'react-helmet-async'
// import '../../CssFiles/Wpl.css'


const Wpl = () => {

    const body = document.querySelector('#root');
	body.scrollIntoView({
	}, [])

    const [cat, setCat] = useState([])
    const [page, setPage] = useState(1)
    const [nrofpages, setNumberofpage] = useState(1);

    useEffect(() => {
        getpost()
    }, [page, setCat])

    // Event handler: Decrease page count no lower then 1.
    const showPrevPage = () => setPage(page - 1 ? page - 1 : 1);
    // Event handler: Increase page count no higher then nrofpages.
    const showNextPage = () => setPage(page < nrofpages ? page + 1 : nrofpages);


    const getpost = async () => {

        const url = `https://sabhitech.com/wp-json/wp/v2/posts?_embed&per_page=9&categories=5721&page=${page}`
        await axios.get(url).then((res) => {
            setCat(res.data);
            setNumberofpage(res.headers["x-wp-totalpages"]);
            // console.log(res.data)
        });
    }

    // console.log('cat', cat)
    return (
        <div className='container '>
            <Helmet>
                <title>Womens Premier League 2023</title>
                <meta name='description' content=" Get Live Cricket Scores, Scorecard, Schedules of International and Domestic cricket matches along with Latest News, Videos and ICC Cricket Rankings of ..." />
                <link rel="canonical" href="https://cricpoint.in/womens-premier-league" />
            </Helmet>
            <div className="container">
                <div className="row">
                    {cat.map((po) => {
                        return (
                            <div key={po.id} class="card m-4 cards" style={{ width: "18rem" }}>
                                <img class=" image" style={{width:"auto", height:"200px"}} src={po.fimg_url} alt="Card image cap" />
                                <div class="card-body">
                                    <h5 class="card-title" dangerouslySetInnerHTML={{ __html: po.title.rendered}}></h5>
                                    <p class="card-text" dangerouslySetInnerHTML={{ __html: po.excerpt.rendered.slice(0, 150) }}></p>
                                    {/* <link to="/post/${po.id}">read more</link> */}
                                    <Link to={`/post/${po.slug}`} class="btn btns btn-primary">Read More..</Link>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
            {/* pagination srction */}
            <div className="posts-post-nav">
                <button onClick={showPrevPage}>&#60;</button>
                <p>
                    Page {page} of {nrofpages}
                </p>
                <button onClick={showNextPage}>&#62;</button>
            </div>
        </div>
    )
}

export default Wpl;