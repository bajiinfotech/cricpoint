import React from 'react';
import DashboardLayout from "../../layouts/DashboardLayout";

const Posts = () => {
	return (
		<DashboardLayout>
			Posts
		</DashboardLayout>
	)
};

export default Posts;
