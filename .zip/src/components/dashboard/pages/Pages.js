import React from 'react';
import DashboardLayout from "../../layouts/DashboardLayout";

const Pages = () => {
	return (
		<DashboardLayout>
			Pages
		</DashboardLayout>
	)
};

export default Pages;
